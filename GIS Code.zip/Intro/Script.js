
require([
  "esri/config",
  "esri/Map",
  
  "esri/views/MapView",
  "esri/widgets/ScaleBar",
  "esri/widgets/Legend",
  "esri/layers/KMLLayer",
  "esri/layers/FeatureLayer",
  "esri/layers/MapImageLayer",
  "esri/widgets/Popup",
  "esri/layers/support/LabelClass",
  "esri/symbols/TextSymbol"
   
  
], function(esriConfig,Map,  MapView, ScaleBar, Legend,KMLLayer,FeatureLayer,MapImageLayer,Popup,LabelClass,TextSymbol) {

esriConfig.apiKey = "AAPKd618a22668304d46bef2738772b6593bfCyEJX_kFpN0SYkRDaQSMcopf5s2JUROU6_-R7hRCsCZzlJLDciyRkfSlNltWu6a";
const map = new Map({
 basemap: "arcgis/topographic" // basemap styles service

 });

 //const webmap = new WebMap({
  //portalItem: {
 //  id: "54bee11cd32844d7a62d020da49b89da"
  //}
// });

  const view = new MapView({
    container: "viewDiv",
    center: [-87, 21],
    zoom: 6, 
    map: map

  });
  
  // Set minimum and maximum zoom levels
view.constraints = {
  minZoom: 3,
  maxZoom: 15
  }


  const scalebar = new ScaleBar({
    view: view
  });

  view.ui.add(scalebar, "bottom-left");

//const legend = new Legend ({
   // view: view
 // });
  //view.ui.add(legend, "top-right");

  var kmlUrl1 = "https://www.nhc.noaa.gov/storm_graphics/api/AL092021_001Aadv_TRACK.kmz"; // Replace with your KML file URL
  var kmlLayer1 = new KMLLayer({
      url: kmlUrl1,
      visible:false
  });

  var kmlUrl2 = "https://www.nhc.noaa.gov/storm_graphics/api/AL092021_001Aadv_CONE.kmz"; // Replace with your KML file URL
  var kmlLayer2 = new KMLLayer({
      url: kmlUrl2,
      visible:false
  });

  // Once the KML layers are loaded, add them to the map
  Promise.all([kmlLayer1.load(), kmlLayer2.load()]).then(function() {
      map.addMany([kmlLayer1, kmlLayer2]);
  }).catch(function(error) {
      console.error("Error loading KML layers:", error);
  });

  // Listen for changes to the checkboxes and toggle the visibility of the KML layers
  var checkbox1 = document.getElementById("kmlLayer1Checkbox");
  checkbox1.addEventListener("change", function(event) {
      kmlLayer1.visible = event.target.checked;
  });

  var checkbox2 = document.getElementById("kmlLayer2Checkbox");
  checkbox2.addEventListener("change", function(event) {
      kmlLayer2.visible = event.target.checked;
  });
   
 // Define the LabelClass
 var labelClass = new LabelClass({
  // Define the label expression. Here we're labeling with the 'name' field
  labelExpressionInfo: { expression: "$feature.AREA_CODE" },

  
  // Define the text symbol
  symbol: new TextSymbol({
    color: "black",
    haloColor: "white",
    haloSize: "2px",
    font: { // autocast as Font
      family: "Arial",
      size: 12,
      weight: "bold"
    }
  })
});
  //Add Layers with toggle.
  var Area = new FeatureLayer({
    url: "https://services2.arcgis.com/Tk8KtWY399EerUu0/arcgis/rest/services/protclip/FeatureServer",
    // Set the LabelClass on the layer's labelingInfo property
    labelingInfo: [labelClass],
    visible:false
});

var Block = new FeatureLayer({
    url: "https://services2.arcgis.com/Tk8KtWY399EerUu0/arcgis/rest/services/block/FeatureServer/0",
    visible:false
});



// Once the layers are loaded, add them to the map
Promise.all([Area.load(), Block.load()]).then(function() {
    map.addMany([Area, Block]);
}).catch(function(error) {
    console.error("Error loading layers:", error);
});

// Listen for changes to the checkboxes and toggle the visibility of the layers
var checkbox3 = document.getElementById("layer1Checkbox");
checkbox3.addEventListener("change", function(event) {
    Area.visible = event.target.checked;
});

var checkbox4 = document.getElementById("layer2Checkbox");
checkbox4.addEventListener("change", function(event) {
    Block.visible = event.target.checked;

    
});






 // Function to create MapImageLayer for a hurricane
 function createHurricaneLayer(hurricaneUrl) {
  return new FeatureLayer({
    url: hurricaneUrl,
    title: "Hurricane Layer",
    popupTemplate: {
      title: "{STORMNAME}",
      content: [{
        type: "fields",
        fieldInfos: [
          {
            fieldName: "ADVDATE ",
            label: "Advisory Date",
            visible: true
          },
          {
            fieldName: "BASIN ",
            label: "BASIN ",
            visible: true
          },
          {
            fieldName: "LAT ",
            label: "Latitude",
            visible: true
          },
          {
            fieldName: "LON ",
            label: "Longitude",
            visible: true
          },
          {
            fieldName: "MAXWIND  ",
            label: "MAXWIND  ",
            visible: true
          }
        ]
      }]
    }
  
  });
}

// Initial hurricane layer
var hurricaneLayer = createHurricaneLayer("https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/");

map.add(hurricaneLayer);


// Handle dropdown change event
document.getElementById("hurricaneDropdown").addEventListener("change", function(event) {
  var selectedHurricane = event.target.value;
  var hurricaneUrl;

  switch (selectedHurricane) {
    case "hurricane1":
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/0";
      break;
    case "hurricane2":
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/1";
      break;
    case "hurricane3":
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/2";
      break;
      case "hurricane4":
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/3";
      break;
      case "hurricane5":
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/4";
      break;
    default:
      hurricaneUrl = "https://services9.arcgis.com/RHVPKKiFTONKtxq3/arcgis/rest/services/Active_Hurricanes_v1/FeatureServer/";
  }

  // Remove existing layer
  map.remove(hurricaneLayer);

  // Add new hurricane layer
  hurricaneLayer = createHurricaneLayer(hurricaneUrl);
  map.add(hurricaneLayer);

  // Log to console for debugging
  console.log("Added layer for:", selectedHurricane, hurricaneUrl);
});




});
